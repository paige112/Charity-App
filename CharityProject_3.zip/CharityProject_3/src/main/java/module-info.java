module com.example.charityproject_3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.charityproject_3 to javafx.fxml;
    exports com.example.charityproject_3;
}